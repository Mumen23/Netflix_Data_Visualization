# Load necessary libraries
library(ggplot2)
library(dplyr)
library(readr)

# Load the dataset
netflix_data <- read_csv("netflix_data.csv")

# View the structure of the dataset
str(netflix_data)

# Data Cleaning: Remove missing values
netflix_data <- na.omit(netflix_data)

# Data Exploration: Summary statistics
summary(netflix_data)

# Count of most watched genres
genre_count <- netflix_data %>% 
  count(genre, sort = TRUE)

# Plot the most watched genres
ggplot(genre_count, aes(x = reorder(genre, n), y = n)) + 
  geom_bar(stat = "identity", fill = "steelblue") + 
  coord_flip() + 
  labs(title = "Most Watched Genres on Netflix", x = "Genre", y = "Count")

# Ratings distribution
ggplot(netflix_data, aes(x = rating)) + 
  geom_histogram(binwidth = 0.5, fill = "red", color = "black") + 
  labs(title = "Ratings Distribution", x = "Rating", y = "Count")