import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv("netflix_shows_movies.csv")

# Data Cleaning: Handling missing values
df.dropna(inplace=True)

# Data Exploration: Summary statistics
print(df.describe())
print(df.info())

# Most watched genres
plt.figure(figsize=(10, 5))
genre_counts = df['listed_in'].str.split(', ').explode().value_counts().head(10)
sns.barplot(x=genre_counts.index, y=genre_counts.values, palette='coolwarm')
plt.xlabel("Genre")
plt.ylabel("Count")
plt.title("Top 10 Most Watched Genres")
plt.xticks(rotation=45)
plt.show()

# Ratings distribution
plt.figure(figsize=(10, 5))
sns.histplot(df['rating'], bins=20, kde=True, color='blue')
plt.xlabel("Rating")
plt.ylabel("Frequency")
plt.title("Distribution of Ratings")
plt.show()

# Save cleaned data
df.to_csv("Netflix_shows_movies.csv", index=False)